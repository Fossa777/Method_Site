---
title: "Деление Ichthyophthirius multifiliis"
description: 'Палинтомическое деление томонта после выхода из рыбы.'
video_id: "Ichthyophthirius"
type: "video"
---

