---
title: "Cryptocaryon irritans в жабрах"
description: 'Трофонты Cryptocaryon irritans в жаберном эпителии рыбы. Видео демонстрирует жаберную форму криптокарионоза, которая может протекать без характерных белых точек на коже.'
video_id: "Cryptocaryon"
type: "video"
---

